﻿using dotnetapp.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Data    
{
public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }
        public DbSet<Loan> Loans { get; set; }
        public DbSet<LoanApplication> LoanApplications { get; set; }
        public DbSet<Feedback> Feedbacks { get; set; }
         public  DbSet<User> Users { get; set; }
protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    base.OnModelCreating(modelBuilder);

    modelBuilder.Entity<Loan>()
        .Property(l => l.InterestRate)
        .HasColumnType("decimal(18,2)");

    modelBuilder.Entity<Loan>()
        .Property(l => l.MaximumAmount)
        .HasColumnType("decimal(18,2)");

    modelBuilder.Entity<LoanApplication>()
        .Property(la => la.Income)
        .HasColumnType("decimal(18,2)");

    modelBuilder.Entity<LoanApplication>()
        .Property(la => la.PurchasePrice)
        .HasColumnType("decimal(18,2)");

    // Other entity configurations go here...
}

}
}