using System.ComponentModel.DataAnnotations;

namespace dotnetapp.Models
{
    public class Loan
    {        
        public int LoanId { get; set; }

        [Required(ErrorMessage = "Loan type is required")]
        public string LoanType { get; set; }

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Interest rate is required")]
        public decimal InterestRate { get; set; }

        [Required(ErrorMessage = "Maximum amount is required")]
        public decimal MaximumAmount { get; set; }
    }
}
