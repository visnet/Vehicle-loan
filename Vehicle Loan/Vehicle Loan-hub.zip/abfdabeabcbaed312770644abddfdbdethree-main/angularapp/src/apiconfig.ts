export const apiUrl = 'https://8080-fcebccfceabbafdecbafcaaffabb.premiumproject.examly.io';
