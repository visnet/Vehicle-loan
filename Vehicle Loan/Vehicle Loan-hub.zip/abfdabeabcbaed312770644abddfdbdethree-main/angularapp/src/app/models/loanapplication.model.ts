export interface LoanApplication {
    LoanApplicationId?: number;
    UserId?: number;
    UserName: string;
    LoanId?: number;
    SubmissionDate: String;
    Income: number;
    Model: string;
    PurchasePrice: number;
    LoanStatus: number;
    Address: string;
    File: string;
}


