using dotnetapp.Exceptions;
using dotnetapp.Models;
using dotnetapp.Data;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System.Linq;
using System.Reflection;
using dotnetapp.Services;
using System;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http;
using System.Text;

namespace dotnetapp.Tests
{
    [TestFixture]
    public class Tests
    {

        private ApplicationDbContext _context; 
        private HttpClient _httpClient;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(databaseName: "TestDatabase").Options;
            _context = new ApplicationDbContext(options);
           
             _httpClient = new HttpClient();
             _httpClient.BaseAddress = new Uri("http://localhost:8080");

        }

        [TearDown]
        public void TearDown()
        {
             _context.Dispose();
        }




   [Test, Order(1)]
    public async Task Backend_Test_Post_Method_Register_Admin()
    {
        ClearDatabase();
        string uniqueId = Guid.NewGuid().ToString();

        // Generate a unique userName based on a timestamp
        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"Admin\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        Console.WriteLine(response.StatusCode);
        string responseString = await response.Content.ReadAsStringAsync();

        Console.WriteLine(responseString);
        Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
    }
     [Test, Order(2)]
    public async Task Backend_Test_Post_Method_Login_Admin()
    {
        ClearDatabase();

        string uniqueId = Guid.NewGuid().ToString();

        // Generate a unique userName based on a timestamp
        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"Admin\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        // Print registration response
        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        // Login with the registered user
        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
    }


    [Test, Order(3)]
    public async Task Backend_Test_Post_Method_Register_User()
    {
        ClearDatabase();
        string uniqueId = Guid.NewGuid().ToString();

        // Generate a unique userName based on a timestamp
        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"User\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        Console.WriteLine(response.StatusCode);
        string responseString = await response.Content.ReadAsStringAsync();

        Console.WriteLine(responseString);
        Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

    }

    [Test, Order(4)]
    public async Task Backend_Test_Post_Method_Login_User()
    {
        ClearDatabase();

        string uniqueId = Guid.NewGuid().ToString();

        // Generate a unique userName based on a timestamp
        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"User\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        // Print registration response
        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        // Login with the registered user
        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
    }

   [Test, Order(5)]
    public async Task Backend_Test_Post_Loan_By_Admin()
    {
        ClearDatabase();
        string uniqueId = Guid.NewGuid().ToString();

        // Generate a unique userName based on a timestamp
        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"Admin\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        // Print registration response
        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        // Login with the registered user
        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
        string responseBody = await loginResponse.Content.ReadAsStringAsync();

        dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

        string token = responseMap.token;

        Assert.IsNotNull(token);

        string uniquetitle = Guid.NewGuid().ToString();

        // Use a dynamic and unique userName for admin (appending timestamp)
        string uniqueloantype = $"loan_{uniquetitle}";

        string loanjson = $"{{\"LoanType\":\"{uniqueloantype}\",\"Description\":\"test\",\"InterestRate\":10,\"MaximumAmount\":1000}}";
        _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
        HttpResponseMessage loanresponse = await _httpClient.PostAsync("/api/loan",
        new StringContent(loanjson, Encoding.UTF8, "application/json"));

       Console.WriteLine("loanresponse"+loanresponse);

        Assert.AreEqual(HttpStatusCode.OK, loanresponse.StatusCode);
    }

   [Test, Order(6)]
    public async Task Backend_Test_Post_Loan_By_User_Returns_Forbidden()
    {
        ClearDatabase();
        string uniqueId = Guid.NewGuid().ToString();
        // Generate a unique userName based on a timestamp
        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"User\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        // Print registration response
        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        // Login with the registered user
        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
        string responseBody = await loginResponse.Content.ReadAsStringAsync();

        dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

        string token = responseMap.token;

        Assert.IsNotNull(token);

        string uniquetitle = Guid.NewGuid().ToString();

        // Use a dynamic and unique userName for admin (appending timestamp)
        string uniqueloantype = $"loan_{uniquetitle}";

        string loanjson = $"{{\"LoanType\":\"{uniqueloantype}\",\"Description\":\"test\",\"InterestRate\":10,\"MaximumAmount\":1000}}";
        _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
        HttpResponseMessage loanresponse = await _httpClient.PostAsync("/api/loan",
        new StringContent(loanjson, Encoding.UTF8, "application/json"));

       Console.WriteLine("loanresponse"+loanresponse);

        Assert.AreEqual(HttpStatusCode.Forbidden, loanresponse.StatusCode);
    }
   [Test, Order(7)]

    public async Task Backend_Test_Post_Loan_Without_Token_By_Admin_Returns_Unauthorize()
    {
        ClearDatabase();
        string uniqueId = Guid.NewGuid().ToString();

        // Generate a unique userName based on a timestamp
        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"Admin\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        // Print registration response
        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        // Login with the registered user
        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
 
        string uniquetitle = Guid.NewGuid().ToString();

        // Use a dynamic and unique userName for admin (appending timestamp)
        string uniqueloantype = $"loan_{uniquetitle}";

        string loanjson = $"{{\"LoanType\":\"{uniqueloantype}\",\"Description\":\"test\",\"InterestRate\":10,\"MaximumAmount\":1000}}";
        HttpResponseMessage loanresponse = await _httpClient.PostAsync("/api/loan",
        new StringContent(loanjson, Encoding.UTF8, "application/json"));

       Console.WriteLine("loanresponse"+loanresponse);

        Assert.AreEqual(HttpStatusCode.Unauthorized, loanresponse.StatusCode);
    }

   [Test, Order(8)]
    public async Task Backend_Test_Get_Method_Get_all_Loans_By_Admin()
    {
         ClearDatabase();

        string uniqueId = Guid.NewGuid().ToString();

        // Generate a unique userName based on a timestamp
        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"Admin\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        // Print registration response
        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        // Login with the registered user
        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
        string responseBody = await loginResponse.Content.ReadAsStringAsync();

        dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

        string token = responseMap.token;

        Assert.IsNotNull(token);

        _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
         HttpResponseMessage loanresponse = await _httpClient.GetAsync("/api/loan");
        Assert.AreEqual(HttpStatusCode.OK, loanresponse.StatusCode);
    }



   [Test, Order(9)]
    public async Task Backend_Test_Get_Method_Get_all_Loans_By_User()
    {
        ClearDatabase();
        string uniqueId = Guid.NewGuid().ToString();

        // Generate a unique userName based on a timestamp
        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"User\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        // Print registration response
        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        // Login with the registered user
        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
        string responseBody = await loginResponse.Content.ReadAsStringAsync();

        dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

        string token = responseMap.token;

        Assert.IsNotNull(token);

        _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
         HttpResponseMessage loanresponse = await _httpClient.GetAsync("/api/loan");
        Assert.AreEqual(HttpStatusCode.OK, loanresponse.StatusCode);
    }

   [Test, Order(10)]
    public async Task Backend_Test_Get_Method_Get_all_Loans_Without_Token_Returns_Unauthorize_By_Admin()
    {
        ClearDatabase();

        string uniqueId = Guid.NewGuid().ToString();

        // Generate a unique userName based on a timestamp
        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\":  \"1234567890\", \"UserRole\": \"Admin\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        // Print registration response
        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        // Login with the registered user
        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
   
        HttpResponseMessage loanresponse = await _httpClient.GetAsync("/api/loan");
        Assert.AreEqual(HttpStatusCode.Unauthorized, loanresponse.StatusCode);
    }


   [Test, Order(11)]
    public async Task Backend_Test_Get_Method_Get_all_Loan_Applications_By_Admin()
    {
        ClearDatabase();

        string uniqueId = Guid.NewGuid().ToString();

        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"Admin\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
        string responseBody = await loginResponse.Content.ReadAsStringAsync();

        dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

        string token = responseMap.token;

        Assert.IsNotNull(token);

        _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
         HttpResponseMessage loanresponse = await _httpClient.GetAsync("/api/loan-application");
        Assert.AreEqual(HttpStatusCode.OK, loanresponse.StatusCode);
    }

   [Test, Order(12)]

    public async Task Backend_Test_Get_Method_Get_all_Loan_Applications_By_User_Returns_Forbidden()
    {
         ClearDatabase();

        string uniqueId = Guid.NewGuid().ToString();

        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"User\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
        string responseBody = await loginResponse.Content.ReadAsStringAsync();

        dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

        string token = responseMap.token;

        Assert.IsNotNull(token);
        _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
         HttpResponseMessage loanresponse = await _httpClient.GetAsync("/api/loan-application");
        Assert.AreEqual(HttpStatusCode.Forbidden, loanresponse.StatusCode);
    }


   [Test, Order(13)]
    public async Task Backend_Test_Get_Method_Get_All_Feedbacks_By_Admin()
    {
        ClearDatabase();

        string uniqueId = Guid.NewGuid().ToString();

        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"Admin\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
        string responseBody = await loginResponse.Content.ReadAsStringAsync();

        dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

        string token = responseMap.token;

        Assert.IsNotNull(token);
        _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
         HttpResponseMessage loanresponse = await _httpClient.GetAsync("/api/feedback");
        Assert.AreEqual(HttpStatusCode.OK, loanresponse.StatusCode);
    }
   
   [Test, Order(14)]
    public async Task Backend_Test_Get_Method_Get_All_Feedbacks_By_User_Returns_Forbidden()
    {
        ClearDatabase();
        string uniqueId = Guid.NewGuid().ToString();

        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"User\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
        string responseBody = await loginResponse.Content.ReadAsStringAsync();

        dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

        string token = responseMap.token;

        Assert.IsNotNull(token);
        _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
         HttpResponseMessage loanresponse = await _httpClient.GetAsync("/api/feedback");
        Assert.AreEqual(HttpStatusCode.Forbidden, loanresponse.StatusCode);
    }
   
   [Test, Order(15)]

     public async Task Backend_Test_Get_Method_Get_All_Feedbacks_By_Admin_Without_Token_Returns_Unauthorize()
    {
        ClearDatabase();

        string uniqueId = Guid.NewGuid().ToString();

        string uniqueUsername = $"abcd_{uniqueId}";
        string uniqueEmail = $"abcd{uniqueId}@gmail.com";

        string requestBody = $"{{\"Username\": \"{uniqueUsername}\", \"Password\": \"abc@123A\", \"Email\": \"{uniqueEmail}\", \"MobileNumber\": \"1234567890\", \"UserRole\": \"Admin\"}}";
        HttpResponseMessage response = await _httpClient.PostAsync("/api/register", new StringContent(requestBody, Encoding.UTF8, "application/json"));

        string registerResponseBody = await response.Content.ReadAsStringAsync();
        Console.WriteLine("Registration Response: " + registerResponseBody);

        string loginRequestBody = $"{{\"Email\" : \"{uniqueEmail}\",\"Password\" : \"abc@123A\"}}"; // Updated variable names
        HttpResponseMessage loginResponse = await _httpClient.PostAsync("/api/login", new StringContent(loginRequestBody, Encoding.UTF8, "application/json"));

        // Print login response
        string loginResponseBody = await loginResponse.Content.ReadAsStringAsync();
        Console.WriteLine("Login Response: " + loginResponseBody);

        Assert.AreEqual(HttpStatusCode.OK, loginResponse.StatusCode);
      
         HttpResponseMessage loanresponse = await _httpClient.GetAsync("/api/feedback");

        Assert.AreEqual(HttpStatusCode.Unauthorized, loanresponse.StatusCode);
    }

 [Test, Order(16)]
public async Task Backend_Test_Get_Method_Get_LoanById_In_Loan_Service_Fetches_Loan_Successfully()
{
    ClearDatabase();

     var loanData = new Dictionary<string, object>
    {
        { "LoanId", 20},
        { "LoanType", "Personal Loan" },
        { "Description", "A loan for personal expenses" },
        { "InterestRate", 8.5m },
        { "MaximumAmount", 10000m }
    };

    var loan = new Loan();
    foreach (var kvp in loanData)
    {
        var propertyInfo = typeof(Loan).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loan, kvp.Value);
        }
    }
    _context.Loans.Add(loan);
    _context.SaveChanges();

    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.LoanService";
    string typeName = "dotnetapp.Models.Loan";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);


    MethodInfo getLoanMethod = serviceType.GetMethod("GetLoanById");
  

    if (getLoanMethod != null)
    {
        var service = Activator.CreateInstance(serviceType, _context);
        var retrievedLoan = (Task<Loan>)getLoanMethod.Invoke(service, new object[] { 20 });

        Assert.IsNotNull(retrievedLoan);
        Assert.AreEqual(loan.LoanType, retrievedLoan.Result.LoanType);
    }
    else
    {
        Assert.Fail();
    }

}

[Test, Order(17)]
public async Task Backend_Test_Put_Method_UpdateLoan_In_Loan_Service_Updates_Loan_Successfully()
{
    ClearDatabase();
     var loanData = new Dictionary<string, object>
    {
        { "LoanId", 20},
        { "LoanType", "Personal Loan" },
        { "Description", "A loan for personal expenses" },
        { "InterestRate", 8.5m },
        { "MaximumAmount", 10000m }
    };

    var loan = new Loan();
    foreach (var kvp in loanData)
    {
        var propertyInfo = typeof(Loan).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loan, kvp.Value);
        }
    }
    _context.Loans.Add(loan);
    _context.SaveChanges();

    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.LoanService";
    string typeName = "dotnetapp.Models.Loan";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);


    MethodInfo updatemethod = serviceType.GetMethod("UpdateLoan", new[] { typeof(int), modelType });


    if (updatemethod != null)
    {
        var service = Activator.CreateInstance(serviceType, _context);
        // Update the loan
        var updatedLoanData = new Dictionary<string, object>
        {
            { "LoanId", 20 },
            { "LoanType", "Updated Personal Loan" },
            { "Description", "An updated loan for personal expenses" },
            { "InterestRate", 7.5m},
            { "MaximumAmount", 15000m }
        };

        var updatedLoan = Activator.CreateInstance(modelType);
        foreach (var kvp in updatedLoanData)
        {
            var propertyInfo = modelType.GetProperty(kvp.Key);
            if (propertyInfo != null)
            {
                propertyInfo.SetValue(updatedLoan, kvp.Value);
            }
        }

        var updateResult = (Task<bool>)updatemethod.Invoke(service, new object[] { 20, updatedLoan });

        var updatedLoanFromDb = await _context.Loans.FindAsync(20);
        Assert.IsNotNull(updatedLoanFromDb);
        Assert.AreEqual("Updated Personal Loan", updatedLoanFromDb.LoanType);
        Assert.AreEqual("An updated loan for personal expenses", updatedLoanFromDb.Description);

    }
    else
    {
        Assert.Fail();
    }   
}

[Test, Order(18)]
public async Task Backend_Test_Delete_Method_DeleteLoan_In_Loan_Service_Deletes_Loan_Successfully()
{
     ClearDatabase();
      // Add loan
    var loanData = new Dictionary<string, object>
    {
        { "LoanId", 4 },
        { "LoanType", "Personal Loan" },
        { "Description", "A loan for personal expenses" },
        { "InterestRate", 8.5m },
        { "MaximumAmount", 10000m }
    };

    var loan = new Loan();
    foreach (var kvp in loanData)
    {
        var propertyInfo = typeof(Loan).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loan, kvp.Value);
        }
    }

    _context.Loans.Add(loan);
    _context.SaveChanges();

    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.LoanService";
    string typeName = "dotnetapp.Models.Loan";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);

    MethodInfo deletemethod = serviceType.GetMethod("DeleteLoan", new[] { typeof(int) });

    if (deletemethod != null)
    {
        var service = Activator.CreateInstance(serviceType, _context);
        var deleteResult = (Task<bool>)deletemethod.Invoke(service, new object[] { 4 });

        var deletedLoanFromDb = await _context.Loans.FindAsync(4);
        Assert.IsNull(deletedLoanFromDb);
    }
    else
    {
        Assert.Fail();
    }
}

[Test, Order(19)]
public async Task Backend_Test_Post_Method_AddLoanApplication_In_LoanApplication_Service_Posts_Successfully()
{
    ClearDatabase();

    // Add user
    var userData = new Dictionary<string, object>
    {
        { "UserId", 400 },
        { "Username", "testuser" },
        { "Password", "testpassword" },
        { "Email", "test@example.com" },
        { "MobileNumber", "1234567890" },
        { "UserRole", "User" }
    };

    var user = new User();
    foreach (var kvp in userData)
    {
        var propertyInfo = typeof(User).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(user, kvp.Value);
        }
    }
    _context.Users.Add(user);
    _context.SaveChanges();

    var loanData = new Dictionary<string, object>
    {
        { "LoanId", 100 },
        { "LoanType", "Personal Loan" },
        { "Description", "A loan for personal expenses" },
        { "InterestRate", 8.5m },
        { "MaximumAmount", 10000m }
    };

    var loan = new Loan();
    foreach (var kvp in loanData)
    {
        var propertyInfo = typeof(Loan).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loan, kvp.Value);
        }
    }
    _context.Loans.Add(loan);
    _context.SaveChanges();

    // Add loan application
    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.LoanApplicationService";
    string typeName = "dotnetapp.Models.LoanApplication";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);

    MethodInfo method = serviceType.GetMethod("AddLoanApplication", new[] { modelType });

    if (method != null)
    {
        var loanApplicationData = new Dictionary<string, object>
        {
            { "LoanApplicationId", 200 },
            { "UserId", 400 },
            { "LoanId", 100 },
            { "SubmissionDate", DateTime.Now },
            { "Income", 50000m },
            { "Model", DateTime.Now },
            { "PurchasePrice", 250000m },
            { "LoanStatus", 1 },
            { "Address", "123 Main St, City, Country" },
            { "File", "loan_application.pdf" }
        };

        var loanApplication = Activator.CreateInstance(modelType);
        foreach (var kvp in loanApplicationData)
        {
            var propertyInfo = modelType.GetProperty(kvp.Key);
            if (propertyInfo != null)
            {
                propertyInfo.SetValue(loanApplication, kvp.Value);
            }
        }
        var service = Activator.CreateInstance(serviceType, _context);
        var result = (Task<bool>)method.Invoke(service, new object[] { loanApplication });
    
        var addedLoanApplication = await _context.LoanApplications.FindAsync(200);
        Assert.IsNotNull(addedLoanApplication);
        Assert.AreEqual("loan_application.pdf",addedLoanApplication.File);

    }
    else{
        Assert.Fail();
    }
}

[Test, Order(20)]
public async Task Backend_Test_Get_Method_GetLoanApplicationByUserId_In_LoanApplication_Fetches_Successfully()
{
    // Add user
         ClearDatabase();

    var userData = new Dictionary<string, object>
    {
        { "UserId", 400 },
        { "Username", "testuser" },
        { "Password", "testpassword" },
        { "Email", "test@example.com" },
        { "MobileNumber", "1234567890" },
        { "UserRole", "User" }
    };

    var user = new User();
    foreach (var kvp in userData)
    {
        var propertyInfo = typeof(User).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(user, kvp.Value);
        }
    }
    _context.Users.Add(user);
    _context.SaveChanges();

    var loanData = new Dictionary<string, object>
    {
        { "LoanId", 100 },
        { "LoanType", "Personal Loan" },
        { "Description", "A loan for personal expenses" },
        { "InterestRate", 8.5m },
        { "MaximumAmount", 10000m }
    };

    var loan = new Loan();
    foreach (var kvp in loanData)
    {
        var propertyInfo = typeof(Loan).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loan, kvp.Value);
        }
    }
    _context.Loans.Add(loan);
    _context.SaveChanges();


    var loanApplicationData = new Dictionary<string, object>
        {
            { "LoanApplicationId", 200 },
            { "UserId", 400 },
            { "LoanId", 100 },
            { "SubmissionDate", DateTime.Now },
            { "Income", 50000m },
            { "Model", DateTime.Now },
            { "PurchasePrice", 250000m },
            { "LoanStatus", 1 },
            { "Address", "123 Main St, City, Country" },
            { "File", "loan_application.pdf" }
        };
    var loanApplication = new LoanApplication();
    foreach (var kvp in loanApplicationData)
    {
        var propertyInfo = typeof(LoanApplication).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loanApplication, kvp.Value);
        }
    }
    _context.LoanApplications.Add(loanApplication);
    _context.SaveChanges();

    // Add loan application
    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.LoanApplicationService";
    string typeName = "dotnetapp.Models.LoanApplication";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);

    MethodInfo method = serviceType.GetMethod("GetLoanApplicationsByUserId");

    if (method != null)
    {
        var service = Activator.CreateInstance(serviceType, _context);
        var result = ( Task<IEnumerable<LoanApplication>>)method.Invoke(service, new object[] {400});
        Assert.IsNotNull(result);
          var check=true;
        foreach (var item in result.Result)
        {   
            check=false;
            Assert.AreEqual("123 Main St, City, Country", item.Address);
            Assert.AreEqual(50000m, item.Income); 
            Assert.AreEqual(250000m, item.PurchasePrice); 
            Assert.AreEqual(1, item.LoanStatus);
        }

        if(check==true)
        {
        Assert.Fail();
        }
    }
    else{
        Assert.Fail();
    }
}

[Test, Order(21)]

public async Task Backend_Test_Put_Method_Update_In_LoanApplication_Service_Updates_Successfully()
{
     ClearDatabase();

    var userData = new Dictionary<string, object>
    {
        { "UserId", 400 },
        { "Username", "testuser" },
        { "Password", "testpassword" },
        { "Email", "test@example.com" },
        { "MobileNumber", "1234567890" },
        { "UserRole", "User" }
    };

    var user = new User();
    foreach (var kvp in userData)
    {
        var propertyInfo = typeof(User).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(user, kvp.Value);
        }
    }
    _context.Users.Add(user);
    _context.SaveChanges();


    var loanData = new Dictionary<string, object>
    {
        { "LoanId", 100 },
        { "LoanType", "Personal Loan" },
        { "Description", "A loan for personal expenses" },
        { "InterestRate", 8.5m },
        { "MaximumAmount", 10000m }
    };

    var loan = new Loan();
    foreach (var kvp in loanData)
    {
        var propertyInfo = typeof(Loan).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loan, kvp.Value);
        }
    }
    _context.Loans.Add(loan);
    _context.SaveChanges();


    var loanApplicationData = new Dictionary<string, object>
        {
            { "LoanApplicationId", 200 },
            { "UserId", 400 },
            { "LoanId", 100 },
            { "SubmissionDate", DateTime.Now },
            { "Income", 50000m },
            { "Model", DateTime.Now },
            { "PurchasePrice", 250000m },
            { "LoanStatus", 1 },
            { "Address", "123 Main St, City, Country" },
            { "File", "loan_application.pdf" }
        };
    var loanApplication = new LoanApplication();
     foreach (var kvp in loanApplicationData)
    {
        var propertyInfo = typeof(LoanApplication).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loanApplication, kvp.Value);
        }
    }
    _context.LoanApplications.Add(loanApplication);
    _context.SaveChanges();

    // Add loan application
    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.LoanApplicationService";
    string typeName = "dotnetapp.Models.LoanApplication";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);

    MethodInfo method = serviceType.GetMethod("UpdateLoanApplication",new[] { typeof(int), modelType });

    if (method != null)
    {
          var updatedLoanApplicationData = new Dictionary<string, object>
        {
            { "UserId", 400 },
            { "LoanId", 100 },
            { "SubmissionDate", DateTime.Now },
            { "Income", 50000m },
            { "Model", DateTime.Now },
            { "PurchasePrice", 250000m },
            { "LoanStatus", 1 },
            { "Address", "new 123 Main St, City, Country" },
            { "File", "loan_application.pdf" }
        };
    var updatedLoanApplication = new LoanApplication();
    foreach (var kvp in updatedLoanApplicationData)
    {
        var propertyInfo = typeof(LoanApplication).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(updatedLoanApplication, kvp.Value);
        }
    }

        var service = Activator.CreateInstance(serviceType, _context);
        var updateResult = (Task<bool>)method.Invoke(service, new object[] { 200, updatedLoanApplication });
        var updatedLoanFromDb = await _context.LoanApplications.FindAsync(200);
        Assert.IsNotNull(updatedLoanFromDb);
        Assert.AreEqual("new 123 Main St, City, Country", updatedLoanFromDb.Address);   
    }
    else{
        Assert.Fail();
    }
}

[Test, Order(22)]
public async Task Backend_Test_Delete_Method_DeleteLoanApplication_Service_Deletes_LoanApplication_Successfully()
{

    var userData = new Dictionary<string, object>
    {
        { "UserId", 32 },
        { "Username", "testuser" },
        { "Password", "testpassword" },
        { "Email", "test@example.com" },
        { "MobileNumber", "1234567890" },
        { "UserRole", "User" }
    };

    var user = new User();
    foreach (var kvp in userData)
    {
        var propertyInfo = typeof(User).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(user, kvp.Value);
        }
    }
    _context.Users.Add(user);
    _context.SaveChanges();


    var loanData = new Dictionary<string, object>
    {
        { "LoanId", 33 },
        { "LoanType", "Personal Loan" },
        { "Description", "A loan for personal expenses" },
        { "InterestRate", 8.5m },
        { "MaximumAmount", 10000m }
    };

    var loan = new Loan();
    foreach (var kvp in loanData)
    {
        var propertyInfo = typeof(Loan).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loan, kvp.Value);
        }
    }
    _context.Loans.Add(loan);
    _context.SaveChanges();


    var loanApplicationData = new Dictionary<string, object>
        {
            { "LoanApplicationId", 20 },
            { "UserId", 32 },
            { "LoanId", 33 },
            { "SubmissionDate", DateTime.Now },
            { "Income", 50000m },
            { "Model", DateTime.Now },
            { "PurchasePrice", 250000m },
            { "LoanStatus", 1 },
            { "Address", "123 Main St, City, Country" },
            { "File", "loan_application.pdf" }
        };
    var loanApplication = new LoanApplication();
     foreach (var kvp in loanApplicationData)
    {
        var propertyInfo = typeof(LoanApplication).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loanApplication, kvp.Value);
        }
    }
    _context.LoanApplications.Add(loanApplication);
    _context.SaveChanges();


    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.LoanApplicationService";
    string typeName = "dotnetapp.Models.LoanApplication";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);

    MethodInfo deletemethod = serviceType.GetMethod("DeleteLoanApplication", new[] { typeof(int) });

    if (deletemethod != null)
    {
        var service = Activator.CreateInstance(serviceType, _context);
        var deleteResult = (Task<bool>)deletemethod.Invoke(service, new object[] { 20 });

        var deletedLoanFromDb = await _context.LoanApplications.FindAsync(20);
        Assert.IsNull(deletedLoanFromDb);
    }
    else
    {
        Assert.Fail();
    }
     ClearDatabase();
}

[Test, Order(23)]
public async Task Backend_Test_Post_Method_AddFeedback_In_Feedback_Service_Posts_Successfully()
{
        ClearDatabase();

    // Add user
    var userData = new Dictionary<string, object>
    {
        { "UserId",42 },
        { "Username", "testuser" },
        { "Password", "testpassword" },
        { "Email", "test@example.com" },
        { "MobileNumber", "1234567890" },
        { "UserRole", "User" }
    };

    var user = new User();
    foreach (var kvp in userData)
    {
        var propertyInfo = typeof(User).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(user, kvp.Value);
        }
    }
    _context.Users.Add(user);
    _context.SaveChanges();
    // Add loan application
    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.FeedbackService";
    string typeName = "dotnetapp.Models.Feedback";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);

    MethodInfo method = serviceType.GetMethod("AddFeedback", new[] { modelType });

    if (method != null)
    {
           var feedbackData = new Dictionary<string, object>
            {
                { "FeedbackId", 11 },
                { "UserId", 42 },
                { "FeedbackText", "Great experience!" },
                { "Date", DateTime.Now }
            };
        var feedback = new Feedback();
        foreach (var kvp in feedbackData)
        {
            var propertyInfo = typeof(Feedback).GetProperty(kvp.Key);
            if (propertyInfo != null)
            {
                propertyInfo.SetValue(feedback, kvp.Value);
            }
        }
        var service = Activator.CreateInstance(serviceType, _context);
        var result = (Task<bool>)method.Invoke(service, new object[] { feedback });
    
        var addedFeedback= await _context.Feedbacks.FindAsync(11);
        Assert.IsNotNull(addedFeedback);
        Assert.AreEqual("Great experience!",addedFeedback.FeedbackText);

    }
    else{
        Assert.Fail();
    }
}

[Test, Order(24)]
public async Task Backend_Test_Delete_Method_Feedback_In_Feeback_Service_Deletes_Successfully()
{
    // Add user
     ClearDatabase();

    var userData = new Dictionary<string, object>
    {
        { "UserId",42 },
        { "Username", "testuser" },
        { "Password", "testpassword" },
        { "Email", "test@example.com" },
        { "MobileNumber", "1234567890" },
        { "UserRole", "User" }
    };

    var user = new User();
    foreach (var kvp in userData)
    {
        var propertyInfo = typeof(User).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(user, kvp.Value);
        }
    }
    _context.Users.Add(user);
    _context.SaveChanges();

           var feedbackData = new Dictionary<string, object>
            {
                { "FeedbackId", 11 },
                { "UserId", 42 },
                { "FeedbackText", "Great experience!" },
                { "Date", DateTime.Now }
            };
        var feedback = new Feedback();
        foreach (var kvp in feedbackData)
        {
            var propertyInfo = typeof(Feedback).GetProperty(kvp.Key);
            if (propertyInfo != null)
            {
                propertyInfo.SetValue(feedback, kvp.Value);
            }
        }
     _context.Feedbacks.Add(feedback);
    _context.SaveChanges();
    // Add loan application
    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.FeedbackService";
    string typeName = "dotnetapp.Models.Feedback";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);

  
    MethodInfo deletemethod = serviceType.GetMethod("DeleteFeedback", new[] { typeof(int) });

    if (deletemethod != null)
    {
        var service = Activator.CreateInstance(serviceType, _context);
        var deleteResult = (Task<bool>)deletemethod.Invoke(service, new object[] { 11 });

        var deletedFeedbackFromDb = await _context.Feedbacks.FindAsync(11);
        Assert.IsNull(deletedFeedbackFromDb);
    }
    else
    {
        Assert.Fail();
    }
}

[Test, Order(25)]
public async Task Backend_Test_Get_Method_GetFeedbacksByUserId_In_Feedback_Service_Fetches_Successfully()
{
        ClearDatabase();

    // Add user
    var userData = new Dictionary<string, object>
    {
        { "UserId", 330 },
        { "Username", "testuser" },
        { "Password", "testpassword" },
        { "Email", "test@example.com" },
        { "MobileNumber", "1234567890" },
        { "UserRole", "User" }
    };

    var user = new User();
    foreach (var kvp in userData)
    {
        var propertyInfo = typeof(User).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(user, kvp.Value);
        }
    }
    _context.Users.Add(user);
    _context.SaveChanges();

    var feedbackData= new Dictionary<string, object>
    {
        { "FeedbackId", 13 },
        { "UserId", 330 },
        { "FeedbackText", "Great experience!" },
        { "Date", DateTime.Now }
    };

    var feedback = new Feedback();
    foreach (var kvp in feedbackData)
    {
        var propertyInfo = typeof(Feedback).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(feedback, kvp.Value);
        }
    }
    _context.Feedbacks.Add(feedback);
    _context.SaveChanges();

    // Add loan application
    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.FeedbackService";
    string typeName = "dotnetapp.Models.Feedback";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);

    MethodInfo method = serviceType.GetMethod("GetFeedbacksByUserId");

    if (method != null)
    {
        var service = Activator.CreateInstance(serviceType, _context);
        var result = ( Task<IEnumerable<Feedback>>)method.Invoke(service, new object[] {330});
        Assert.IsNotNull(result);
         var check=true;
        foreach (var item in result.Result)
        {
            check=false;
            Assert.AreEqual("Great experience!", item.FeedbackText);
   
        }
        if(check==true)
        {
            Assert.Fail();

        }
    }
    else{
        Assert.Fail();
    }
}

//Exception
[Test, Order(26)]
 
public async Task Backend_Test_Post_Method_AddLoan_In_LoanService_Occurs_LoanException_For_Duplicate_LoanType()
   {
         ClearDatabase();

    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.LoanService";
    string typeName = "dotnetapp.Models.Loan";
 
    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);
 
    MethodInfo method = serviceType.GetMethod("AddLoan", new[] { modelType });
 
    if (method != null)
    {
        var loanData = new Dictionary<string, object>
        {
            { "LoanId", 2 },
            { "LoanType", "Personal Loan" },
            { "Description", "A loan for personal expenses" },
            { "InterestRate", 8.5m},
            { "MaximumAmount", 10000m }
        };
 
        var loan = Activator.CreateInstance(modelType);
        foreach (var kvp in loanData)
        {
            var propertyInfo = modelType.GetProperty(kvp.Key);
            if (propertyInfo != null)
            {
                propertyInfo.SetValue(loan, kvp.Value);
            }
        }
 
        var service = Activator.CreateInstance(serviceType, _context);
        var result = (Task<bool>)method.Invoke(service, new object[] { loan });
        var addedLoan = await _context.Loans.FindAsync(2);
        Assert.IsNotNull(addedLoan);
        var loanData1 = new Dictionary<string, object>
        {
            { "LoanId", 3 },
            { "LoanType", "Personal Loan" },
            { "Description", "A loan for personal expenses" },
            { "InterestRate", 8.5m},
            { "MaximumAmount", 10000m }
        };
 
        var loan1 = Activator.CreateInstance(modelType);
        foreach (var kvp in loanData1)
        {
            var propertyInfo = modelType.GetProperty(kvp.Key);
            if (propertyInfo != null)
            {
                propertyInfo.SetValue(loan1, kvp.Value);
            }
        }
 
        try
        {
            var result1 = (Task<bool>)method.Invoke(service, new object[] { loan1 });
            Console.WriteLine("res"+result1.Result); 
            Assert.Fail();

        }
        catch (Exception ex)
        {

            Assert.IsNotNull(ex.InnerException);
            Assert.IsTrue(ex.InnerException is LoanException);
            Assert.AreEqual("Loan with the same type already exists", ex.InnerException.Message);
    }
    }
    else
    {
        Assert.Fail();
    }
   }
 

[Test, Order(27)]

public async Task Backend_Test_Post_Method_AddLoanApplication_In_LoanApplication_Service_Throws_LoanException_As_Already_Applied()
{
     ClearDatabase();

    var userData = new Dictionary<string, object>
    {
        { "UserId", 400 },
        { "Username", "testuser" },
        { "Password", "testpassword" },
        { "Email", "test@example.com" },
        { "MobileNumber", "1234567890" },
        { "UserRole", "User" }
    };

    var user = new User();
    foreach (var kvp in userData)
    {
        var propertyInfo = typeof(User).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(user, kvp.Value);
        }
    }
    _context.Users.Add(user);
    _context.SaveChanges();

    var loanData = new Dictionary<string, object>
    {
        { "LoanId", 100 },
        { "LoanType", "Personal Loan" },
        { "Description", "A loan for personal expenses" },
        { "InterestRate", 8.5m },
        { "MaximumAmount", 10000m }
    };

    var loan = new Loan();
    foreach (var kvp in loanData)
    {
        var propertyInfo = typeof(Loan).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loan, kvp.Value);
        }
    }
    _context.Loans.Add(loan);
    _context.SaveChanges();

    // Add loan application
    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.LoanApplicationService";
    string typeName = "dotnetapp.Models.LoanApplication";

    Type serviceType = assembly.GetType(ServiceName);
    Type modelType = assembly.GetType(typeName);

    MethodInfo method = serviceType.GetMethod("AddLoanApplication", new[] { modelType });

    if (method != null)
    {
        var loanApplicationData = new Dictionary<string, object>
        {
            { "LoanApplicationId", 200 },
            { "UserId", 400 },
            { "LoanId", 100 },
            { "SubmissionDate", DateTime.Now },
            { "Income", 50000m },
            { "Model", DateTime.Now },
            { "PurchasePrice", 250000m },
            { "LoanStatus", 1 },
            { "Address", "123 Main St, City, Country" },
            { "File", "loan_application.pdf" }
        };

        var loanApplication = Activator.CreateInstance(modelType);
        foreach (var kvp in loanApplicationData)
        {
            var propertyInfo = modelType.GetProperty(kvp.Key);
            if (propertyInfo != null)
            {
                propertyInfo.SetValue(loanApplication, kvp.Value);
            }
        }

        var service = Activator.CreateInstance(serviceType, _context);
        var result = (Task<bool>)method.Invoke(service, new object[] { loanApplication });
    
        var addedLoanApplication = await _context.LoanApplications.FindAsync(200);
        Assert.IsNotNull(addedLoanApplication);
        Console.WriteLine("addedLoanApplication"+addedLoanApplication.LoanApplicationId);

          try
          {
            var result1 = (Task<bool>)method.Invoke(service, new object[] { loanApplication });
            var message= result1.Result;
             Assert.Fail(); 
        }
        catch (Exception ex)
        {
            Assert.IsNotNull(ex.InnerException);
            Assert.IsTrue(ex.InnerException is LoanException);
            Assert.AreEqual("User already applied for this loan", ex.InnerException.Message);
        }
    }
    else{
        Assert.Fail();
    }
}

[Test, Order(28)]

public async Task Backend_Test_Delete_Method_DeleteLoan_In_Loan_Service_Throws_LoanException_As_Referenced()
{
    // Add user
    ClearDatabase();
    var userData = new Dictionary<string, object>
    {
        { "UserId", 400 },
        { "Username", "testuser" },
        { "Password", "testpassword" },
        { "Email", "test@example.com" },
        { "MobileNumber", "1234567890" },
        { "UserRole", "User" }
    };

    var user = new User();
    foreach (var kvp in userData)
    {
        var propertyInfo = typeof(User).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(user, kvp.Value);
        }
    }
    _context.Users.Add(user);
    _context.SaveChanges();

    // Add loan
    var loanData = new Dictionary<string, object>
    {
        { "LoanId", 100 },
        { "LoanType", "Personal Loan" },
        { "Description", "A loan for personal expenses" },
        { "InterestRate", 8.5m },
        { "MaximumAmount", 10000m }
    };

    var loan = new Loan();
    foreach (var kvp in loanData)
    {
        var propertyInfo = typeof(Loan).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loan, kvp.Value);
        }
    }
    _context.Loans.Add(loan);
    _context.SaveChanges();


    var loanApplicationData = new Dictionary<string, object>
        {
            { "LoanApplicationId", 200 },
            { "UserId", 400 },
            { "LoanId", 100 },
            { "SubmissionDate", DateTime.Now },
            { "Income", 50000m },
            { "Model", DateTime.Now },
            { "PurchasePrice", 250000m },
            { "LoanStatus", 1 },
            { "Address", "123 Main St, City, Country" },
            { "File", "loan_application.pdf" }
        };
    var loanApplication = new LoanApplication();
    foreach (var kvp in loanApplicationData)
    {
        var propertyInfo = typeof(LoanApplication).GetProperty(kvp.Key);
        if (propertyInfo != null)
        {
            propertyInfo.SetValue(loanApplication, kvp.Value);
        }
    }
        _context.LoanApplications.Add(loanApplication);
       _context.SaveChanges();
  
    string assemblyName = "dotnetapp";
    Assembly assembly = Assembly.Load(assemblyName);
    string ServiceName = "dotnetapp.Services.LoanService";

    Type serviceType = assembly.GetType(ServiceName);

    MethodInfo deletemethod = serviceType.GetMethod("DeleteLoan", new[] { typeof(int) });
    var service = Activator.CreateInstance(serviceType, _context);

    if (deletemethod != null)
    {
          try
          {
            var deleteResult = (Task<bool>)deletemethod.Invoke(service, new object[] { 100 });
            var message= deleteResult.Result;
             Assert.Fail(); 
        }
        catch (Exception ex)
        {
            Assert.IsNotNull(ex.InnerException);
            Assert.IsTrue(ex.InnerException is LoanException);
            Assert.AreEqual("Loan cannot be deleted, it is referenced in loanapplication", ex.InnerException.Message);
        }
    }
    else{
        Assert.Fail();
    }
}


private void ClearDatabase()
{
    _context.Database.EnsureDeleted();
    _context.Database.EnsureCreated();
}


      [Test, Order(29)]
        public void Backend_Test_ApplicationDbContext_ContainsDbSet_Loan()
        {
            Assembly assembly = Assembly.GetAssembly(typeof(ApplicationDbContext));
 
            Type contextType = assembly.GetTypes().FirstOrDefault(t => typeof(DbContext).IsAssignableFrom(t));
            if (contextType == null)
            {
                Assert.Fail("No DbContext found in the assembly");
                return;
            }
            Type LoanType = assembly.GetTypes().FirstOrDefault(t => t.Name == "Loan");
            if (LoanType == null)
            {
                Assert.Fail("No DbSet found in the DbContext");
                return;
            }
            var propertyInfo = contextType.GetProperty("Loans");
            if (propertyInfo == null)
            {
                Assert.Fail("Loans property not found in the DbContext");
                return;
            }
            else
            {
                Assert.AreEqual(typeof(DbSet<>).MakeGenericType(LoanType), propertyInfo.PropertyType);
            }
        }
    
    [Test, Order(30)]
       public void Backend_Test_ApplicationDbContext_Contains_DbSet_LoanApplication()
        {
            Assembly assembly = Assembly.GetAssembly(typeof(ApplicationDbContext));
 
            Type contextType = assembly.GetTypes().FirstOrDefault(t => typeof(DbContext).IsAssignableFrom(t));
            if (contextType == null)
            {
                Assert.Fail("No DbContext found in the assembly");
                return;
            }
            Type LoanApplicationType = assembly.GetTypes().FirstOrDefault(t => t.Name == "LoanApplication");
            if (LoanApplicationType == null)
            {
                Assert.Fail("No DbSet found in the DbContext");
                return;
            }
            var propertyInfo = contextType.GetProperty("LoanApplications");
            if (propertyInfo == null)
            {
                Assert.Fail("LoanApplications property not found in the DbContext");
                return;
            }
            else
            {
                Assert.AreEqual(typeof(DbSet<>).MakeGenericType(LoanApplicationType), propertyInfo.PropertyType);
            }
        }
 
 
 
     [Test, Order(31)]
        public void Backend_Test_ApplicationDbContext_Contains_DbSet_Feedback()
        {
            Assembly assembly = Assembly.GetAssembly(typeof(ApplicationDbContext));
 
            Type contextType = assembly.GetTypes().FirstOrDefault(t => typeof(DbContext).IsAssignableFrom(t));
            if (contextType == null)
            {
                Assert.Fail("No DbContext found in the assembly");
                return;
            }
            Type FeedbackType = assembly.GetTypes().FirstOrDefault(t => t.Name == "Feedback");
            if (FeedbackType == null)
            {
                Assert.Fail("No DbSet found in the DbContext");
                return;
            }
            var propertyInfo = contextType.GetProperty("Feedbacks");
            if (propertyInfo == null)
            {
                Assert.Fail("Feedbacks property not found in the DbContext");
                return;
            }
            else
            {
                Assert.AreEqual(typeof(DbSet<>).MakeGenericType(FeedbackType), propertyInfo.PropertyType);
            }
        }
 
 
     [Test, Order(32)]
    public void Backend_Test_ApplicationDbContext_Contains_DbSet_User()
        {
            Assembly assembly = Assembly.GetAssembly(typeof(ApplicationDbContext));
 
            Type contextType = assembly.GetTypes().FirstOrDefault(t => typeof(DbContext).IsAssignableFrom(t));
            if (contextType == null)
            {
                Assert.Fail("No DbContext found in the assembly");
                return;
            }
            Type UserType = assembly.GetTypes().FirstOrDefault(t => t.Name == "User");
            if (UserType == null)
            {
                Assert.Fail("No DbSet found in the DbContext");
                return;
            }  
        }
       
    
     [Test, Order(33)]
        public void Backend_Test_Loan_LoanId_PropertyExists_ReturnExpectedDataTypes_int()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.Loan";
            string propertyName = "LoanId";
            Type expectedType = typeof(int);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);     }
     
     [Test, Order(34)]
        public void Backend_Test_Loan_LoanType_PropertyExists_ReturnExpectedDataTypes_string()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.Loan";
            string propertyName = "LoanType";
            Type expectedType = typeof(string);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
 
     [Test, Order(35)]
        public void Backend_Test_Loan_InterestRate_PropertyExists_ReturnExpectedDataTypes_decimal()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.Loan";
            string propertyName = "InterestRate";
            Type expectedType = typeof(decimal);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(36)]
        public void Backend_Test_Loan_Description_PropertyExists_ReturnExpectedDataTypes_string()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.Loan";
            string propertyName = "Description";
            Type expectedType = typeof(string);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(37)]
        public void Backend_Test_Loan_MaximumAmount_PropertyExists_ReturnExpectedDataTypes_decimal()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.Loan";
            string propertyName = "MaximumAmount";
            Type expectedType = typeof(decimal);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
 
     [Test, Order(38)]
        public void Backend_Test_LoanApplication_LoanApplicationId_PropertyExists_ReturnExpectedDataType_int()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.LoanApplication";
            string propertyName = "LoanApplicationId";
            Type expectedType = typeof(int);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(39)]
        public void Backend_Test_LoanApplication_UserId_PropertyExists_ReturnExpectedDataType_int()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.LoanApplication";
            string propertyName = "UserId";
            Type expectedType = typeof(int);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(40)]
        public void Backend_Test_LoanApplication_LoanId_PropertyExists_ReturnExpectedDataType_int()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.LoanApplication";
            string propertyName = "LoanId";
            Type expectedType = typeof(int);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(41)]
        public void Backend_Test_LoanApplication_SubmissionDate_PropertyExists_ReturnExpectedDataType_DateTime()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.LoanApplication";
            string propertyName = "SubmissionDate";
            Type expectedType = typeof(DateTime);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(42)]
        public void Backend_Test_LoanApplication_Income_PropertyExists_ReturnExpectedDataType_decimal()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.LoanApplication";
            string propertyName = "Income";
            Type expectedType = typeof(decimal);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(43)]
        public void Backend_Test_LoanApplication_Model_PropertyExists_ReturnExpectedDataType_DateTime()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.LoanApplication";
            string propertyName = "Model";
            Type expectedType = typeof(DateTime);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(44)]
        public void Backend_Test_LoanApplication_PurchasePrice_PropertyExists_ReturnExpectedDataType_decimal()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.LoanApplication";
            string propertyName = "PurchasePrice";
            Type expectedType = typeof(decimal);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(45)]
        public void Backend_Test_LoanApplication_LoanStatus_PropertyExists_ReturnExpectedDataType_int()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.LoanApplication";
            string propertyName = "LoanStatus";
            Type expectedType = typeof(int);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(46)]
     public void Backend_Test_LoanApplication_Address_PropertyExists_ReturnExpectedDataType_string()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.LoanApplication";
            string propertyName = "Address";
            Type expectedType = typeof(string);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
 
     [Test, Order(47)]
    public void Backend_Test_LoanApplication_File_PropertyExists_ReturnExpectedDataType_string()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.LoanApplication";
            string propertyName = "File";
            Type expectedType = typeof(string);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(48)]
     public void Backend_Test_Feedback_FeedbackId_PropertyExists_ReturnExpectedDataType_int()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.Feedback";
            string propertyName = "FeedbackId";
            Type expectedType = typeof(int);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(49)]
      public void Backend_Test_Feedback_UserId_PropertyExists_ReturnExpectedDataType_int()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.Feedback";
            string propertyName = "UserId";
            Type expectedType = typeof(int);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(50)]
      public void Backend_Test_Feedback_FeedbackText_PropertyExists_ReturnExpectedDataType_string()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.Feedback";
            string propertyName = "FeedbackText";
            Type expectedType = typeof(string);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
     [Test, Order(51)]
    public void Backend_Test_Feedback_Date_PropertyExists_ReturnExpectedDataType_DateTime()
        {
            string assemblyName = "dotnetapp";
            string typeName = "dotnetapp.Models.Feedback";
            string propertyName = "Date";
            Type expectedType = typeof(DateTime);
            ValidatePropertyType(assemblyName, typeName, propertyName, expectedType);
        }
 
    [Test, Order(52)]
    public void Backend_Test_Migration_Folder_Exists()
    {

        string folderPath = @"/home/coder/project/workspace/dotnetapp/Migrations"; // Replace with the folder path you want to check
        bool folderExists = Directory.Exists(folderPath);
        Assert.IsTrue(folderExists, "The folder does not exist.");

    }

       [Test, Order(53)]
        public void Backend_Test_Migration_Files_Exist()
        {
            string folderPath = @"/home/coder/project/workspace/dotnetapp/Migrations";
            bool filesExist = Directory.GetFiles(folderPath).Length > 0;
            Assert.IsTrue(filesExist, "No migration files found in the folder.");
        }


        private void ValidatePropertyType(string assemblyName, string typeName, string propertyName, Type expectedType)
        {
            Assembly assembly = Assembly.Load(assemblyName);
            Type assemblyType = assembly.GetType(typeName);
            PropertyInfo propertyInfo = assemblyType.GetProperty(propertyName);
            Assert.IsNotNull(propertyInfo, $"Property {propertyName} does not exist in {typeName} class");
            Type actualType = propertyInfo.PropertyType;
            Assert.AreEqual(expectedType, actualType, $"Property {propertyName} in {typeName} class is not of type {expectedType.Name}");
        }

      }
    }






